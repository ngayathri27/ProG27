import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-shopnow',
  templateUrl: './shopnow.component.html',
  styleUrls: ['./shopnow.component.css']
})
export class ShopnowComponent implements OnInit {

  constructor() {
   }

  ngOnInit(): void {
  }

}
